<?php
declare(strict_types=1);
/**
 * The template for displaying the front page.
 *
 * @package Faminga_Theme_v1
 */

get_header(); 

// Get the translated texts for the current language
$t = faminga_get_translated_texts();
?>

	<!-- Transparency styles for parallax effect -->
	<style>
		section {
			background-color: rgba(10, 42, 15, 0.75) !important;
			backdrop-filter: blur(5px);
			position: relative;
			z-index: 1;
		}
		
		.feature-card {
			background: rgba(0, 51, 0, 0.3) !important;
			backdrop-filter: blur(8px);
			border: 1px solid rgba(82, 103, 0, 0.3);
			box-shadow: 0 0 20px rgba(82, 103, 0, 0.1);
		}
		
		.feature-card:hover {
			background: rgba(0, 51, 0, 0.5) !important;
			border-color: rgba(82, 103, 0, 0.5);
			box-shadow: 0 0 30px rgba(82, 103, 0, 0.2);
		}
		
		.solution-card {
			background: rgba(0, 51, 0, 0.3) !important;
			backdrop-filter: blur(8px);
			border: 1px solid rgba(82, 103, 0, 0.3);
			box-shadow: 0 0 20px rgba(82, 103, 0, 0.1);
		}
		
		.solution-card:hover {
			background: rgba(0, 51, 0, 0.5) !important;
			border-color: rgba(82, 103, 0, 0.5);
			box-shadow: 0 0 30px rgba(82, 103, 0, 0.2);
		}
		
		.hero-section {
			background: linear-gradient(90deg, rgba(0, 26, 0, 0.6) 0%, rgba(0, 26, 0, 0.4) 50%, rgba(0, 26, 0, 0.2) 100%) !important;
		}
		
		.hero-section::before {
			opacity: 0.5 !important;
		}
		
		.dashboard-preview {
			background-color: rgba(0, 0, 0, 0.4) !important;
			backdrop-filter: blur(8px);
		}
	</style>

	<!-- Parallax Background Image -->
	<div id="parallax-bg" class="fixed inset-0 w-full h-full bg-cover bg-center opacity-0 transition-opacity duration-1000 -z-10" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/bg.png'); transform: translateZ(-1px) scale(2);"></div>

	<main id="main" class="site-main relative">

		<!-- Include homepage sections with translations passed as variables -->
		<?php include get_template_directory() . '/templates/sections/homepage.php'; ?>

		<!-- Back to Top Button -->
		<button id="back-to-top" class="fixed bottom-8 right-8 bg-primary hover:bg-primary/80 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 opacity-0 invisible z-50" aria-label="Back to top">
			<i class="fas fa-arrow-up"></i>
		</button>

	</main><!-- #main -->

<?php
get_footer(); ?>

<script>
	// Parallax Background Effect
	document.addEventListener('DOMContentLoaded', function() {
		const parallaxBg = document.getElementById('parallax-bg');
		
		// Fade in the background initially
		setTimeout(function() {
			parallaxBg.style.opacity = '0.8'; // 80% visibility
		}, 300);
		
		// Parallax effect on scroll
		window.addEventListener('scroll', function() {
			const scrollY = window.scrollY;
			const parallaxSpeed = 0.5;
			
			// Move the background at a different rate than the scroll
			parallaxBg.style.transform = `translateZ(-1px) scale(2) translateY(${scrollY * parallaxSpeed}px)`;
			
			// Optional: Add more animation based on scroll position
			if (scrollY > 100) {
				// Add additional animation classes or change opacity
				parallaxBg.style.opacity = Math.max(0.6 - (scrollY * 0.0005), 0.2); // Gradually fade to minimum 0.2 opacity
			} else {
				parallaxBg.style.opacity = '0.9';
			}
		});
	});
</script> 
