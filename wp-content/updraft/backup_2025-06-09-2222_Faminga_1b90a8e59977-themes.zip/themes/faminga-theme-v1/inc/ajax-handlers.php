<?php
declare(strict_types=1);

/**
 * This file is for custom AJAX handlers.
 */
