<?php
declare(strict_types=1);

/**
 * This file is for custom helper functions.
 *
 * It's a good place for code that is reused across the theme.
 * You can organize functions by namespaces.
 */ 