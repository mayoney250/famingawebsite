<?php
declare(strict_types=1);

/**
 * This file is for custom theme hooks, actions, and filters.
 */
